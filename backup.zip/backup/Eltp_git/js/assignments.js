// spiral matrix

const createSpiralMatrix = (n) => {
    const matrix = [];
    let [row, col] = position;
    let currentDirection = "R";

    for (let count = 1; count <= n * n; count++) {
        matrix[row] = matrix[row] || [];
        matrix[row][col] = count;

        if (currentDirection === "R") {
            if (col === n - 1 || matrix[row][col + 1]) {
                currentDirection = "D";
                row += 1;
                continue;
            }

            col += 1;
        }
        if (currentDirection === "L") {
            if (col === 0 || matrix[row][col - 1]) {
                currentDirection = "U";
                row -= 1;
                continue;
            }

            col -= 1;
        }

        if (currentDirection === "D") {
            if (row === n - 1 || (matrix[row + 1] && matrix[row + 1][col])) {
                currentDirection = "L";
                col -= 1;
                continue;
            }

            row += 1;
        }

        if (currentDirection === "U") {
            if (row === 0 || (matrix[row - 1] && matrix[row - 1][col])) {
                currentDirection = "R";
                col += 1;
                continue;
            }

            row -= 1;
        }
    }
    return matrix;
}