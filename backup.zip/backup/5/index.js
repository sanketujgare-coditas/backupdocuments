comst="something messsage";
const products=[
    'Tv',
    'Mobile',
    'Headphone',
    'Refrigerator',
    'Chair',
    'Table',
    'Ipad',
    'Book',
    'Mouse',
    'Desk',
    'Monitor'

];