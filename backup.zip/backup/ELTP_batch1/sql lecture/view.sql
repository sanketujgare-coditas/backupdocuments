Enter password: ****
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 21
Server version: 8.3.0 MySQL Community Server - GPL

Copyright (c) 2000, 2024, Oracle and/or its affiliates.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> use eltp_batch1;
Database changed
mysql> craete table employees(id int primary key, name varchar(100), department varchar(100));
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'craete table employees(id int primary key, name varchar(100), department varchar' at line 1
mysql> craete table employees(id int primary key, name varchar(100), department varchar(100);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'craete table employees(id int primary key, name varchar(100), department varchar' at line 1
mysql> create table employees(id int primary key, name varchar(100), department varchar(100);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
mysql> craete table employees(id int primary key, name varchar(100), department varchar(100));
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'craete table employees(id int primary key, name varchar(100), department varchar' at line 1
mysql> create table employees(id int primary key, name varchar(100), department varchar(100));
Query OK, 0 rows affected (0.05 sec)

mysql> dessc employees;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'dessc employees' at line 1
mysql> desc employees;
+------------+--------------+------+-----+---------+-------+
| Field      | Type         | Null | Key | Default | Extra |
+------------+--------------+------+-----+---------+-------+
| id         | int          | NO   | PRI | NULL    |       |
| name       | varchar(100) | YES  |     | NULL    |       |
| department | varchar(100) | YES  |     | NULL    |       |
+------------+--------------+------+-----+---------+-------+
3 rows in set (0.01 sec)

mysql> INSERT INTO employees (id, name, department)
    -> VALUES
    ->     (1, 'Ravi Kumar', 'Engineering'),
    ->     (2, 'Priya Patel', 'HR'),
    ->     (3, 'Amit Singh', 'Finance'),
    ->     (4, 'Divya Sharma', 'Marketing'),
    ->     (5, 'Rajesh Gupta', 'Sales');
Query OK, 5 rows affected (0.01 sec)
Records: 5  Duplicates: 0  Warnings: 0

mysql> create view sales_employee as select id, name from employees where department='sales';
Query OK, 0 rows affected (0.01 sec)

mysql> select * from employees;
+----+--------------+-------------+
| id | name         | department  |
+----+--------------+-------------+
|  1 | Ravi Kumar   | Engineering |
|  2 | Priya Patel  | HR          |
|  3 | Amit Singh   | Finance     |
|  4 | Divya Sharma | Marketing   |
|  5 | Rajesh Gupta | Sales       |
+----+--------------+-------------+
5 rows in set (0.00 sec)

mysql> show full tables;
+-----------------------+------------+
| Tables_in_eltp_batch1 | Table_type |
+-----------------------+------------+
| country               | BASE TABLE |
| department            | BASE TABLE |
| district              | BASE TABLE |
| employee              | BASE TABLE |
| employee_department   | BASE TABLE |
| employees             | BASE TABLE |
| fb_user               | BASE TABLE |
| passport              | BASE TABLE |
| person                | BASE TABLE |
| sales                 | BASE TABLE |
| sales_employee        | VIEW       |
| state                 | BASE TABLE |
| student               | BASE TABLE |
| teacher               | BASE TABLE |
+-----------------------+------------+
14 rows in set (0.01 sec)

mysql> select * from sales_employees;
ERROR 1146 (42S02): Table 'eltp_batch1.sales_employees' doesn't exist
mysql> select * from sales_employee;
+----+--------------+
| id | name         |
+----+--------------+
|  5 | Rajesh Gupta |
+----+--------------+
1 row in set (0.00 sec)

mysql> desc sales_employee;
+-------+--------------+------+-----+---------+-------+
| Field | Type         | Null | Key | Default | Extra |
+-------+--------------+------+-----+---------+-------+
| id    | int          | NO   |     | NULL    |       |
| name  | varchar(100) | YES  |     | NULL    |       |
+-------+--------------+------+-----+---------+-------+
2 rows in set (0.01 sec)

mysql> create view hr_employees as selectid, name from employees where department='HR';
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'selectid, name from employees where department='HR'' at line 1
mysql> create view hr_employees as select id, name from employees where department='HR';
Query OK, 0 rows affected (0.01 sec)

mysql> select * from hr_employees;
+----+-------------+
| id | name        |
+----+-------------+
|  2 | Priya Patel |
+----+-------------+
1 row in set (0.00 sec)

mysql> select * from hr_employees;
+----+-------------+
| id | name        |
+----+-------------+
|  2 | Priya Patel |
+----+-------------+
1 row in set (0.00 sec)

mysql> update hr_employees set name='JOHN hat' where id=2;
Query OK, 1 row affected (0.01 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select * from hr_employees;
+----+----------+
| id | name     |
+----+----------+
|  2 | JOHN hat |
+----+----------+
1 row in set (0.00 sec)

mysql> select * from employees;
+----+--------------+-------------+
| id | name         | department  |
+----+--------------+-------------+
|  1 | Ravi Kumar   | Engineering |
|  2 | JOHN hat     | HR          |
|  3 | Amit Singh   | Finance     |
|  4 | Divya Sharma | Marketing   |
|  5 | Rajesh Gupta | Sales       |
+----+--------------+-------------+
5 rows in set (0.00 sec)

mysql> create view hr_employees2 as select id, name from employees where department='HR with check option';
Query OK, 0 rows affected (0.01 sec)

mysql> select * from hr_employees2;
Empty set (0.00 sec)

mysql> desc hr_employees2;
+-------+--------------+------+-----+---------+-------+
| Field | Type         | Null | Key | Default | Extra |
+-------+--------------+------+-----+---------+-------+
| id    | int          | NO   |     | NULL    |       |
| name  | varchar(100) | YES  |     | NULL    |       |
+-------+--------------+------+-----+---------+-------+
2 rows in set (0.00 sec)

mysql> drop view employees2;
ERROR 1051 (42S02): Unknown table 'eltp_batch1.employees2'
mysql> drop view hr_employees2;
Query OK, 0 rows affected (0.01 sec)

mysql> create view hr_employees2 as select id, name from employees where department='HR' with check option;
Query OK, 0 rows affected (0.01 sec)

mysql> select * from hr_employees2;
+----+----------+
| id | name     |
+----+----------+
|  2 | JOHN hat |
+----+----------+
1 row in set (0.00 sec)

mysql> update hr_employees2 set name='john hat' where id=2;
Query OK, 1 row affected (0.01 sec)
Rows matched: 1  Changed: 1  Warnings: 0

mysql> select * from hr_employees2;
+----+----------+
| id | name     |
+----+----------+
|  2 | john hat |
+----+----------+
1 row in set (0.00 sec)

mysql> select * from employees;
+----+--------------+-------------+
| id | name         | department  |
+----+--------------+-------------+
|  1 | Ravi Kumar   | Engineering |
|  2 | john hat     | HR          |
|  3 | Amit Singh   | Finance     |
|  4 | Divya Sharma | Marketing   |
|  5 | Rajesh Gupta | Sales       |
+----+--------------+-------------+
5 rows in set (0.00 sec)

mysql> show full tables where table_type like "view";
Empty set (0.01 sec)

mysql> show full tables where table_type like "VIEW";
+-----------------------+------------+
| Tables_in_eltp_batch1 | Table_type |
+-----------------------+------------+
| hr_employees          | VIEW       |
| hr_employees2         | VIEW       |
| sales_employee        | VIEW       |
+-----------------------+------------+
3 rows in set (0.01 sec)

mysql> desc sales_employee;
+-------+--------------+------+-----+---------+-------+
| Field | Type         | Null | Key | Default | Extra |
+-------+--------------+------+-----+---------+-------+
| id    | int          | NO   |     | NULL    |       |
| name  | varchar(100) | YES  |     | NULL    |       |
+-------+--------------+------+-----+---------+-------+
2 rows in set (0.01 sec)

mysql> create or replace view hr_employees as select id,name from employees where department='HR' with check option;
Query OK, 0 rows affected (0.01 sec)

mysql> show full tables where table_type like "VIEW";
+-----------------------+------------+
| Tables_in_eltp_batch1 | Table_type |
+-----------------------+------------+
| hr_employees          | VIEW       |
| hr_employees2         | VIEW       |
| sales_employee        | VIEW       |
+-----------------------+------------+
3 rows in set (0.01 sec)

mysql>