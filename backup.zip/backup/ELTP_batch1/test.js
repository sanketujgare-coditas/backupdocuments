class Maze {
  constructor(arr) {
    this.arr = arr;
    this.path = '';
  }

  checkDown(x, y) {
    if (this.arr[x][y] === '1') {
      this.path += 'S';
      return true;
    }
    return false;
  }

  checkHorizontally(x, y) {
    if (this.arr[x][y] === '1') {
      this.path += 'D';
      return true;
    }
    return false;
  }

  checkLeft(x, y) {
    if (this.arr[x][y] === '1') {
      this.path += 'A';
      return true;
    }
    return false;
  }

  checkUp(x, y) {
    if (this.arr[x][y] === '1') {
      this.path += 'W';
      return true;
    }
    return false;
  }

  solve() {
    let x = 0;
    let y = 0;

    while (x !== this.arr.length - 1 && y !== this.arr[0].length - 1) {

      // if (x === this.arr.length - 1 && y === this.arr[0].length - 1) {
      //   break;
      // }
      if (this.checkHorizontally(x, y + 1)) {
        y = y + 1;
      } else if (this.checkDown(x + 1, y)) {
        x = x + 1;
      } else if (this.checkLeft(x, y - 1)) {
        y = y - 1;
      } else if (this.checkUp(x - 1, y)) {
        x = x - 1;
      } else {
        break; // No valid moves
      }
      
    }

    return this.path;
  }
}

const arr = [
  ['*', '1', '1', '0', '0', '1'],
  ['1', '0', '1', '1', '1', '0'],
  ['0', '0', '0', '0', '1', '0'],
  ['0', '1', '1', '1', '1', '0'],
  ['0', '1', '0', '1', '0', '0'],
  ['0', '1', '1', '1', '1', '1']
];

const obj = new Maze(arr);
const result = obj.solve();
console.log(result);
console.log("printed");
