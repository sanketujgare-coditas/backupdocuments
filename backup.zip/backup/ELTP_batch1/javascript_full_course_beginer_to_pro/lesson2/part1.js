alert('hello');
alert('Good job!');
document.body.innerHTML='hello'
10.90*2 +20.95

lesson 2 exercises:
Math.round(((2095+799)*0.1))/100
2.89
10*1+3*8+1*5;
39
3*(10*1+3*8+1*5)
117

(1850+2*750)/100
33.5
33.5*01
33.5
33.5*0.1
3.35
33.5*0.2
6.7

(1850+2*750)/100
33.5
33.5*01
33.5
33.5*0.1
3.35
33.5*0.2
6.7
1899+2095+799
4793
(1899+2095+799)/100
47.93
(1899+2095+799)/100+4.99
52.92
Math.round(((1899+2095+799)/100+4.99)*0.1)
5
Math.round((((1899+2095+799)/100)+4.99)*0.1)
5
(((1899+2095+799)/100)+4.99)*0.1
5.292000000000001
Math.round((((1899+2095+799)/100)+4.99))*0.1
5.300000000000001
((1899+799+2095)/100)+4.99
52.92
(((1899+799+2095)/100)+4.99)*0.1
5.292000000000001
((((1899+799+2095)/100)+4.99)*0.1)+((1899+799+2095)/100)+4.99
58.212

58.212
(25*9/5)+32
77
(86-32)*5/9
30
(-5*9/5)+32
23

'I am starting new position'
'I am starting new position'
 'I\'m starting new position'
"I'm starting new position"
 "I\'m starting new position"
"I'm starting new position"

`Welcome ${name} to the programming world`
'Welcome sanket to the programming world'