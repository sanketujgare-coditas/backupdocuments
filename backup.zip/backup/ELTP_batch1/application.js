// 3 hard licker
// 2 soft licker
// 1 below 18 first floor

const age=18

const secondthreshold=18;
const thirdthreshold=25;
if(age>=25){
    console.log("Hard liqer go to the 3rd floor")
}
else if(age>=18){
    console.log("soft liquer go to 2nd floor");
}
else{
    console.log("Your are not alow to eat drinks go to first floor");
}

const licker=age>=thirdthreshold?"Third floor":age>=secondthreshold?"second floor":"first floor";
console.log(licker);