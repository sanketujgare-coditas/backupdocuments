
// const arr=["16Gb","lenvo","i7"]
const assignments=["a1","a2","a3"]
const resources=["r1","r2","r3"]

const newarr=[...assignments,...resources]
newarr
// console.log(newarr)

