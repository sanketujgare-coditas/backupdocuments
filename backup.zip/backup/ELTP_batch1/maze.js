class Maze{
    constructor(arr){
        this.arr=arr;
    }
    xoffset;
    ypffset;
    x=0;
    y=0;
    checkvalidmove(x,y,pos){
    if((x<arr.length()-1&& y.arr.length()-1)){
            if(pos==="d"){
                arr[x][y+1]==='1';
                return true;
            }
            if(pos==="s"){
                arr[x][y+1]==='1';
                return true;
            }
    }
    }
    solve(path){
        for(let index=0;index<path.length;index++){
            if(path[index]==="d"){
               this.checkvalidmove(x,y,"d")
            }
            else if(path[index]==="s"){

            }
            else if(path[index]==="a"){

            }
            else if(path[index]==="w"){

            }
        }
    }


}

const arr = [
    ['*', '1', '1', '0', '0', '1'],
    ['1', '0', '1', '1', '1', '0'],
    ['0', '0', '0', '0', '1', '0'],
    ['0', '1', '1', '1', '1', '0'],
    ['0', '1', '0', '1', '0', '0'],
    ['0', '1', '1', '1', '1', '1']
  ];
  
const obj = new Maze(arr);
const path="asdsadda";
const result = obj.solve(path);
console.log(result);
console.log("printed");