// with promises

const getUsersWithPromise = () => {
    return new Promise((resolve, reject) => {
        const users = [1, 2, 3, 4];
        setTimeout(() => {
            const random = Math.random();
            if (random > 0.5) {
                return resolve(users);
            }

            reject("something went wrong")
        }, 3000);
    })
}

const getProductsWithPromise = () => {
    return new Promise((resolve, reject) => {
        const products = ["P1", "P2", "P3", "P4"];
        setTimeout(() => {
            const random = Math.random();
            if (random > 0.5) {
                return resolve(products);
            }

            reject("something went wrong")
        }, 3000);
    })
}

const getPricesWithPromise = () => {
    return new Promise((resolve, reject) => {
        const prices = [10, 20, 30, 40, 50];
        setTimeout(() => {
            const random = Math.random();
            if (random > 0.5) {
                return resolve(prices);
            }

            reject("something went wrong")
        }, 3000);
    })
}

// const userPromise = getUsersWithPromise();

// userPromise.then( users => {
//     return getProductsWithPromise()
// }).then(products => {
//     return getPricesWithPromise()
// }).then(prices => {
//     // prices
//     console.log(prices);    
// }).catch(err => {

// });

// const userPromise = Promise.all([getUsersWithPromise(),getPricesWithPromise(),getProductsWithPromise()]);
// userPromise.then((values) =>{
//     for(let index = 0 ;index<values[0].length;index++){
//         console.log(`User ${values[0][index]} brought the product ${values[2][index]} at price ${values[1][index]}`)
//     }
//     //console.log(values);
// }).catch(err =>{
//     console.log("Something went wrong")
// })

// async await
// const Userpromise=async ()=>{
//     try{
//         const users= await getUsersWithPromise();
//         // console.log(users);
//         for(let i in users){
//             console.log(users[i]);
//         }
//     }
//     catch(e){

//     }
// };
const fetchData = async () => {
    try {
        const [users, prices, products] = await Promise.all([
            getUsersWithPromise(),
            getPricesWithPromise(),
            getProductsWithPromise()
        ]);
        
        for (let index = 0; index < users.length; index++) {
            console.log(`User ${users[index]} bought the product ${products[index]} at price ${prices[index]}`);
        }
    } catch (error) {
        // console.log(error);
    }
};
fetchData();