// console.log(this);

function displayage(){
    console.log(this.age);
    console.log(this);
}

const person={
    age:24,
    displayage:displayage,
    nestedperson:{
        age:28,
        displayage:displayage
    }
}
person.displayage();
console.log("******************");

person.nestedperson.displayage();   

console.log("*********************");

const Human={
    age:28,
    greet1:function(){
        console.log("Greet1", this.age);
        console.log("Greet1", this);

        const greet2=()=>{
            console.log("Greet2", this.age);
            console.log("Greet2", this); 
        }
        greet2();
    }
}

// console.log(typeof Human.greet1);
Human.greet1();

console.log("******************");

var age=78;
const greet3=()=>{
    console.log("Greet3",this.age);
    console.log("Greet3",this);
}
greet3(); 

class Book{
    age=15;
    getage(){
      age=28;
      console.log(this.age);
    }
    get=()=>{
        console.log(this.age);
    }
}
const obj=new Book();
obj.getage();
obj.get();