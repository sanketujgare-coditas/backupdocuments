// // const modifyArray= (arr)=> {
// //     for(let i=0;i<arr.length;i++){
// //         const num=to      arr[i];
// //         arr[i].toNUmber;
// //     }
// //     return arr;

// // };

// // const arr=['a','b','c','d'];
// // const newarr=modifyArray(arr);
// // console.log(newarr);
// const nums=[1,2,3,4,5]

// const filter=(array,cb,0)=>{
//     let sum=0;
//     for(let i=0;i<array.length;i++){
//          const element=array[i];
//          sum=sum+cb(element);
//     }

// };

// const modifyArray=nums.filter(ele=>ele>5);       

// console.log(modifyArray);
const computers=[
    {name:"a",power:5000},
    {name:"b",power:4532},
    {name:"c",power:4987},
    {name:"d",power:3999},
    {name:"e",power:9000}
];

computers.find(ele=>{
    ele.name==='e';
})

let num=8.9
num=parseInt(num);