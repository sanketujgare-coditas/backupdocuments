const getUsersasync =async ()=>{
  try{
    const response=await fetch("https://jsonplaceholder.typicode.com/users/");
    const users= await response.json();
    // console.log(response,users.slice(0,5));
    console.log(response,users.filter(user=>{
        
    }));

  }
  catch(e){

  }
  finally{
    console.log("after all operation");
  }
}
getUsersasync();