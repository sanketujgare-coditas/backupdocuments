const getprices=(handler)=>{
    const prices=[10,20,30,40];
    setTimeout(()=>{
        handler(prices);
    },3000);
}
const getproducts=(handler)=>{
    const products=["p1","p2","p3"];
    setTimeout(()=>{
        handler(products);
    },3000);
}
const getusers=(handler)=>{
    const users=[1,2,3,4];
    setTimeout(()=>{
        handler(users);
    },3000);
}

// getusers(users=>{
//     getproducts(products=>{
//         getprices(prices=>{
//           for(let i in prices ){
//             console.log(i);
//           }
//         })
//         for(let i in products){
//             console.log(i);
//         }
//     })
//     for(let i in users){
//         console.log(i)
// });

const getpricesWithpromise=()=>{
  return new Promise((resolve,reject)=>{
    const prices=[1,2,3,4];
    setTimeout(()=>{
        const random=Math.random();
        if(random>0.5){
            return resolve(prices);
        }
        return reject("something bad happen");
    },3000)
  })
}
const getproductssWithpromise=()=>{
    return new Promise((resolve,reject)=>{
        const products=["p1","p2","p3","p4"];
        setTimeout(()=>{
            const random=Math.random();
            if(random>0.5){
                return resolve(products);
            }
            return reject("something bad happen");
        },3000)
      })
}
const getusersWithpromise=()=>{   
    return new Promise((resolve,reject)=>{
        const users=[1,2,3,4];
        setTimeout(()=>{
            const random=Math.random();
            if(random>0.5){
                return resolve(users);
            }
            return reject("something bad happen");
        },3000)
      })
}

// const 
// get users, products, prices using promise

const userpromise=getpricesWithpromise();
userpromise.then(users=>{
    
})