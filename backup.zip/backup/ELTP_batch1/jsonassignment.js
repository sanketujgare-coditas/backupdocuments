const Someobj={
    person:{
        eyesight:20,
        isWorking:true,
        practice:[
            {dat:"1",hrs:undefined,goal:null},
            {dat:"2",hrs:2,goal:true},
            {dat:"3",hrs:1,goal:false},
        ],
        address:{
            comapany:null,
            home:{
                city:"Pune",
                country:"India",
                cords:{
                    lat:1,
                    long:2
                }
            }
        }
    },
    age:null,
    height:undefined
}

// const removeundefineNull=Someobj=>{
//     for(let key in Someobj){
//         if(Someobj[key]===undefined || Someobj[key]===null){
//             delete Someobj[key];
//         }
//         else if(typeof Someobj[key]===Object){
//             removeundefineNull(Someobj[key]);
//             if(Object.keys(Someobj[key]).length===0){
//                 delete Someobj[key];
//             }
//         }

//     }
// }
const removeundefineNull=JSON.parse(JSON.stringify(Someobj,(key,value)=>{
 if(value===undefined || value===null){
    return undefined;
 }
 return value;
}));


console.log(removeundefineNull);




