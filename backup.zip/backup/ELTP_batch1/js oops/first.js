class Account {
    constructor(accType, accNumber, accHolderName, balance) {
        this.accType = accType;
        this.accNumber = accNumber;
        this.accHolderName = accHolderName;
        this.balance = balance;
    }

    getAccType() {
        return this.accType;
    }

    getAccNumber() {
        return this.accNumber;
    }

    getAccHolderName() {
        return this.accHolderName;
    }

    getBalance() {
        return this.balance;
    }

    toString() {
        return `Account{accType='${this.accType}', accNumber='${this.accNumber}', accHolderName='${this.accHolderName}', balance=${this.balance}}`;
    }

    displayAccInfo() {
        console.log(this.toString());
    }

    deposit(amount) {
        if (amount > 0) {
            this.balance += amount;
            console.log(`${amount} deposited successfully, your new balance is ${this.balance}`);
        } else {
            console.log("You entered an invalid amount");
        }
    }

    withdraw(amount) {
        if (amount > 0 && amount <= this.balance) {
            this.balance -= amount;
            console.log(`${amount} withdrawn successfully, balance is ${this.balance}`);
        } else {
            console.log("Either you entered an invalid amount or have insufficient balance");
        }
    }
}

let account = new Account("Savings", "12345678", "Sanket Ujgare", 0);
account.displayAccInfo();
account.deposit(15000);
account.withdraw(5000);
account.displayAccInfo();







db.test.updateOne({index:1},{
    $set:{
    "company.pantry.biscuits":["monaco","goodday"]}
  }
);