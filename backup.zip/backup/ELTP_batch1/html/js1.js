
const people=[{name:"a",age:20,isHungry:true},{name:"b",age:30,isHungry:true},{name:"c",age:25,isHungry:false}]
for(let {...ele} of people){
    // const age=key[age]
    console.log(ele);
}
for(let key in people){
    const obj=people[key];
    console.log(obj.age   );
}
const keys=Object.keys(people);
for(let key=0;keys.lenght;key++){
    const {val}=people[key];
    console.log(val);
}

// const arr={
//     name:'sanket',
//     age:23,
//     gender:'Male'
// }
// for( let i of arr){
//     console.log(i);
// }