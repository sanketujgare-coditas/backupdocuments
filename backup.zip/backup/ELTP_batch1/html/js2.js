const arr=[];
let maxindex=4*4
let row=0;
let col=0;
let pos;
for(let ele in arr){
    arr[ele]=[];
}
pos="R";
const direction=["R","D","L","U"]
for(let index=1;index<=maxindex;index++){
    // arr[row]=[];
    if(pos==="R"){
        arr[row][col]=index;
        col++;
        pos=col>3?"D":"R";
    }
    else if(pos==="D"){
        arr[row][col]=index;
        row++;
        pos=row>=3?"L":"D";
    }
    else if(pos==="L"){
        arr[row][col]=index;
        col--;
        pos=col<0?"U":"L";
    }
    else if(pos=="U"){
        arr[row][col]=index;
        row--;
        pos=row<0?"R":"U";
    }
}
console.log(arr);

db.employees.insertOne({name:'prakash',age:45,currentctc:4,expectedctc:5,istrustworthy:true,isExperienced:true});
db.employees.insertmany([{name:'santosh',age:45,currentctc:5,expectedctc:5,istrustworthy:true,isExperienced:true},{name:'nayan',age:34,currentctc:4,expectedctc:5,istrustworthy:true,isExperienced:true},{name:'sanket',age:23,currentctc:4,expectedctc:5,istrustworthy:true,isExperienced:true}{name:'Bhavesh',age:34,currentctc:4,expectedctc:5,istrustworthy:true,isExperienced:true}])