// const counter=(initialvalue)=>{
//     return ()=> ++initialvalue;
// }
// const countfrom10=counter(10);
// const countfrom15=counter(15);
// const countfrom20=counter(20);

// console.log(countfrom10());
// console.log(countfrom15());
// console.log(countfrom20());

// countfrom20()
// banking commpany 
// 3 types of loan personalbar,car,Home 
// having differnet Intrest 8 10 12
// calculate intrest;



// const CalculateIntrest=(Principal,Rate,Time)=>{
//     const intrest=(Principal*Rate*Time)/100;
//     // return intrest;
//     const emi=(Principal+intrest)/12
//     return emi;
// }
// const PersonalIntrest=CalculateIntrest(10000,8,3);
// console.log("personal loan ",PersonalIntrest);
// const HomeIntrest=CalculateIntrest(500000,12,5);
// console.log("home loan",HomeIntrest);
// const CarIntrest=CalculateIntrest(200000,10,8);

// console.log("car loan",CarIntrest);

// const loanFactory=(r)=>{
//     return (p,n)=>p*r*n/100;
// }

// const CarLoanCalculator=loanFactory(10);
// const HomeLoanCalculator=loanFactory(12);
// const PersonalLoanCalculator=loanFactory(8);

// CarLoanCalculator(100000,3);

const loanFactory=(r)=>{
    return [
        (p,n)=>p*r*n/100,
        (n)=>r=n
    ]
};
const [CarLoanCalculator,carloanUpdateer]=loanFactory(10);
const HomeLoanCalculator=loanFactory(12);
const PersonalLoanCalculator=loanFactory(8);

console.log(CarLoanCalculator(100000,3));
carloanUpdateer(10.5);
console.log(CarLoanCalculator(100000,3));

