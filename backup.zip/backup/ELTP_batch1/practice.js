

const num=Math.floor(Math.random()*50);
