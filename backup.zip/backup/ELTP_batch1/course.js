1.
console.log(20);
console.log(9);


2.
//opening line 
console.log('It was love at first sight.');

/*console.log('The first time Yossarian saw the chaplain he fell madly in love with him.');
console.log('Yossarian was in the hospital with a pain in his liver that fell just short of being jaundice.');
console.log('The doctors were puzzled by the fact that it wasn\'t quite jaundice.');
console.log('If it became jaundice they could treat it.');
console.log('If it didn\'t become jaundice and went away they could discharge him.');
console.log('But this just being short of jaundice all the time confused them.');
*/

3.
console.log('JavaScript');
console.log(2011);
console.log('Woohoo! I love to code! #codecademy');
console.log(20.49);

4.
console.log(20+3.5);
console.log(2024-1969);
console.log(65/240);
console.log(0.2708*100);

5.
console.log('Hello'+'World');
console.log('Hello'+' ' + 'World');

6.
console.log('Teaching the world how to code'.length);

7.
// Use .toUpperCase() to log 'Codecademy' in all uppercase letters
console.log('Codecademy'.toUpperCase());

// Use a string method to log the following string without whitespace at the beginning and end of it.
console.log('    Remove whitespace   '.trim());

8.
console.log(Math.floor(Math.random()*100));
console.log(Math.ceil(43.8));
console.log(Number.isInteger(2017));

9.
let changeMe=true;

changeMe=false;
console.log(changeMe);

10.
const entree='Enchiladas';
console.log(entree);
entree='Tacos';

11.
let levelUp = 10;
let powerLevel = 9001;
let multiplyMe = 32;
let quarterMe = 1152;

// Use the mathematical assignments in the space below:
levelUp+=5;
powerLevel-=100;
multiplyMe*=11;
quarterMe/=4;

// These console.log() statements below will help you check the values of the variables.
// You do not need to edit these statements. 
console.log('The value of levelUp:', levelUp); 
console.log('The value of powerLevel:', powerLevel); 
console.log('The value of multiplyMe:', multiplyMe); 
console.log('The value of quarterMe:', quarterMe);

12.
let gainedDollar = 3;
let lostDollar = 50;

gainedDollar++;
lostDollar--;

13.
let favoriteAnimal='Cat';
console.log('My favorite animal: '+favoriteAnimal);

14.
let myName='sanket';
let myCity='Pune';
console.log(`My name is ${myName}. My favorite city is ${myCity}`)   

15.
let newVariable = 'Playing around with typeof.';
console.log(typeof newVariable);
newVariable=1;
console.log(typeof newVariable);

2. module
// the kelvin is variable which store the dailyy tempreature
const kelvin=0;
// create variable celsius where ew subtract kelvin to get results in degree.
let celsius=kelvin-273;
// convert celsius tempreature to farenhiet
let fahrenheit=Math.round(celsius*(9/5)+32);

console.log(`The tempreature is ${fahrenheit} degrees Fahrenhiet`);

let newton=Math.round(celsius*(33/100));
console.log(`The tempreature is ${newton} in newton`);

3. module
let myAge=20;
let earlyYears=2;

earlyYears*+10.5;

let laterYears= myAge-2;
// number of dog years accounted for by your later years.
laterYears*=4;

console.log(earlyYears);
console.log(laterYears);

let myAgeInDogYears=earlyYears+laterYears;

let myName='Sanket'.toLowerCase();
console.log(`My name is ${myName}. I am ${myAge} years old in human years which is ${myAgeInDogYears} years old in dog years`);



**************conditions
1.
let sale=true;
sale=false;
if(sale){
  
console.log('Time to buy!')
};

2.
let sale = true;

sale = false;

if(sale) {
  console.log('Time to buy!');
}
else{
  console.log('Time to wait for a sale.');
};

3.
let hungerLevel=7;
if(hungerLevel>7){
  console.log('Time to eat!');
}
else{
  console.log('We can eat later!');
}

4.
let mood = 'sleepy';
let tirednessLevel = 6;

if(mood==='sleepy'&& tirednessLevel>8){
  console.log('time to sleep');
}
else{
  console.log('not bed time yet');
};

5.
let wordCount = 1;

if (wordCount) {
  console.log("Great! You've started your work!");
} else {
  console.log('Better get to work!');
}


let favoritePhrase = '';

if (favoritePhrase) {
  console.log("This string doesn't seem to be empty.");
} else {
  console.log('This string is definitely empty.');
}

6.
let tool = 'marker';

// Use short circuit evaluation to assign  writingUtensil variable below:

let writingUtensil=tool || 'pen';
console.log(`The ${writingUtensil} is mightier than the sword.`);

7.
let isLocked = false;

isLocked ? console.log('You will need a key to open the door.'):  console.log('You will not need a key to open the door.');

let isCorrect = true;

isCorrect? console.log('Correct!'):console.log('Incorrect!');

let favoritePhrase = 'Love That!';

favoritePhrase === 'Love That!' ?console.log('I love that!'):console.log("I don't love that!");

8.
let season = 'winter';

if (season === 'spring') {
  console.log('It\'s spring! The trees are budding!');
  }
else if (season === 'winter') {
  console.log('It\'s winter! Everything is covered in snow.');
}else if (season === 'fall') {
  console.log('It\'s fall! Leaves are falling!');
}else if (season === 'summer') {
  console.log('It\'s sunny and warm because it\'s summer!');
} else {
  console.log('Invalid season.');
};

9.
let athleteFinalPosition = 'first place';
switch(athleteFinalPosition){
  case 'first place':
  console.log('You get the gold medal!');
  break;
  case 'second place':
  console.log('You get the silver medal!');
  break;
  case 'third place':
  console.log('You get the bronze medal!');
  break;
  default:
  console.log("No medal awarded.");
  break;
};

10.

3. module Fuctions:

1.
function getReminder(){
  console.log('Water the plants')
  };
  function greetInSpanish(){
  console.log("Buenas tardes");
  };

  2.
  function sayThanks(){
    console.log('Thank you for your purchase! We appreciate your business.');
  };
   sayThanks();
   sayThanks();
   sayThanks();

   3.
   function sayThanks(name) {
    console.log('Thank you for your purchase ' +name+'! We appreciate your business.');
  };
  
  sayThanks('Cole');

  4.
  function makeShoppingList(item1='milk', item2='bread', item3='eggs'){
    console.log(`Remember to buy ${item1}`);
    console.log(`Remember to buy ${item2}`);
    console.log(`Remember to buy ${item3}`);
  }

  5.
  function monitorCount(rows, columns){
    return rows*columns;
    }
    const numOfMonitors=monitorCount(5,4);
    console.log(numOfMonitors);

  6.
  function monitorCount(rows, columns) {
    return rows * columns;
  }
  
  function costOfMonitors(rows,columns){
     return monitorCount(rows,columns)*200;
  }
  const totalCost=costOfMonitors(5,4);
  console.log(totalCost);

  7.
  const plantNeedsWater= function(day){
    if(day==="Wednesday"){
      return true;
    }
    return false;
    };
    
    console.log(plantNeedsWater('Tuesday'));

    8.
    const plantNeedsWater = (day) =>{
      if (day === 'Wednesday') {
        return true;
      } else {
        return false;
      }
    };
9.
const plantNeedsWater = day => day === 'Wednesday' ? true : false;

4.scope

1.
const city='New York City';
const logCitySkyline=()=>{
  let skyscraper='Empire State Building';
  return 'The stars over the ' + skyscraper + ' in ' + city;
};

console.log(logCitySkyline());

2.
let satellite='The Moon';
let galaxy='The Milky Way';
let stars='North Star';

const callMyNightSky=()=>{
  return 'Night Sky: ' + satellite + ', ' + stars + ', and ' + galaxy;
}
console.log(callMyNightSky());

3.
const logVisibleLightWaves=()=>{
  const lightWaves='Moonlight';
  console.log(lightWaves);
};

logVisibleLightWaves();
console.log(lightWaves);

3.
const satellite = 'The Moon';
const galaxy = 'The Milky Way';
let stars = 'North Star';

const callMyNightSky = () => {
  stars='Sirius';
	return 'Night Sky: ' + satellite + ', ' + stars + ', ' + galaxy;
};

console.log(callMyNightSky());
console.log(stars);

4.
const logVisibleLightWaves = () => {
  let lightWaves = 'Moonlight';
	let region = 'The Arctic';
  // Add if statement here:
  if(region==='The Arctic'){
  let lightWaves='Northern Lights';
  console.log(lightWaves);
  };
  console.log(lightWaves);
};

logVisibleLightWaves();

Array;
1.
const hobbies=['a','b','c'];
console.log(hobbies);

2.
const famousSayings = ['Fortune favors the brave.', 'A joke is a very serious thing.', 'Where there is love there is life.'];
let listItem=famousSayings[0];
console.log(listItem);
console.log(famousSayings[3]);

3.
let groceryList = ['bread', 'tomatoes', 'milk'];
groceryList[1]='avocados';
console.log(groceryList);

4.
let condiments = ['Ketchup', 'Mustard', 'Soy Sauce', 'Sriracha'];

// condiments=['Mayo'];
const utensils = ['Fork', 'Knife', 'Chopsticks', 'Spork'];

condiments[0]='Mayo';
console.log(condiments);
condiments=['Mayo'];
console.log(condiments);
utensils[3]='Spoon';
console.log(utensils);

5.
const objectives = ['Learn a new language', 'Read 52 books', 'Run a marathon'];
console.log(objectives.length);

6.
const chores = ['wash dishes', 'do laundry', 'take out trash'];


chores.push('hello');
chores.push('world');
console.log(chores);

7.
const chores = ['wash dishes', 'do laundry', 'take out trash', 'cook dinner', 'mop floor'];


chores.pop();
console.log(chores);

8.
const groceryList = ['orange juice', 'bananas', 'coffee beans', 'brown rice', 'pasta', 'coconut oil', 'plantains'];

groceryList.shift(groceryList[0]);
console.log(groceryList);
groceryList.unshift('popcorn');
console.log(groceryList);

console.log(groceryList.slice(1,4));
console.log(groceryList);
const pastaIndex=groceryList.indexOf('pasta');
console.log(pastaIndex);

9.
const concept = ['arrays', 'can', 'be', 'mutated'];

function changeArr(arr){
  arr[3] = 'MUTATED';
}

changeArr(concept);
console.log(concept);
const removeElement=(newArr)=>{
  newArr.pop();
};
removeElement(concept);
console.log(concept);

11.

let numberClusters=[[1,2],[3,4],[5,6]];
const target=numberClusters[2][1];

Loops:
1.
// Write your code below


let vacationSpots=['Dubai','Singapoor','Malasia'];
console.log(vacationSpots[0]);
console.log(vacationSpots[1]);
console.log(vacationSpots[2]);

2.
// Write your code below
for(let i=5;i<=10;i++){
  console.log(i);
}

3.
// The loop below loops from 0 to 3. Edit it to loop backwards from 3 to 0
for (let counter = 3; counter>=0; counter--){
  console.log(counter);
}
4.
const vacationSpots = ['Bali', 'Paris', 'Tulum'];

// Write your code below
for(let i=0;i<vacationSpots.length;i++){
  console.log('I would love to visit '+vacationSpots[i]);
};
5.
// Write your code below


let bobsFollowers=['sanket','harsh','jane','maya'];
let tinasFollowers=['jane','harsh','pina'];
let mutualFollowers=[];
for(let i=0;i<bobsFollowers.length;i++){
  for(let j=0;j<tinasFollowers.length;j++){
    if(bobsFollowers[i]===tinasFollowers[j]){
      mutualFollowers.push(bobsFollowers[i]);
    };

  }
}

6.
const cards = ['diamond', 'spade', 'heart', 'club'];

// Write your code below
let currentCard;
while(currentCard!='spade'){
  currentCard = cards[Math.floor(Math.random() * 4)];
console.log(currentCard);
}

7.
// Write your code below

let cupsOfSugarNeeded=8;
let cupsAdded=0;
do{
  cupsAdded++;
}
while(cupsAdded<cupsOfSugarNeeded);

10.
const rapperArray = ["Lil' Kim", "Jay-Z", "Notorious B.I.G.", "Tupac"];

// Write your code below

for(let i=0;i<rapperArray.length;i++){
  if(rapperArray[i]==='Notorious B.I.G.'){
  console.log(rapperArray[i]);
  break;
  }
  
};
console.log("And if you don't know, now you know.");



*************************higher order functions

1.
const checkThatTwoPlusTwoEqualsFourAMillionTimes = () => {
  for(let i = 1; i <= 1000000; i++) {
    if ( (2 + 2) != 4) {
      console.log('Something has gone very wrong :( ');
    }
  }
};

// Write your code below
const isTwoPlusTwo=checkThatTwoPlusTwoEqualsFourAMillionTimes;
isTwoPlusTwo();
console.log(isTwoPlusTwo.name);

2,
const addTwo = num => {
  return num + 2;
}

const checkConsistentOutput = (func, val) => {
let checkA=val+2;
let checkB=func(val);
if(checkA===checkB){
  return checkB;
}
else{
  return 'inconsistent results';
}
}

console.log(checkConsistentOutput(addTwo,2));

**************************Iterators
1.
const fruits = ['mango', 'papaya', 'pineapple', 'apple'];

// Iterate over fruits below
fruits.forEach(fruit=> 
console.log('I want to eat a '+fruit));

2.
const animals = ['Hen', 'elephant', 'llama', 'leopard', 'ostrich', 'Whale', 'octopus', 'rabbit', 'lion', 'dog'];

// Create the secretMessage array below
const secretMessage=animals.map(animal=>{
return animal[0];
});

console.log(secretMessage.join(''));

const bigNumbers = [100, 200, 300, 400, 500];

// Create the smallNumbers array below

3.
const animals = ['Hen', 'elephant', 'llama', 'leopard', 'ostrich', 'Whale', 'octopus', 'rabbit', 'lion', 'dog'];

// Create the secretMessage array below
const secretMessage=animals.map(animal=>{
return animal[0];
});

console.log(secretMessage.join(''));

const bigNumbers = [100, 200, 300, 400, 500];

// Create the smallNumbers array below

const smallNumbers=bigNumbers.map(number=>{
  return number/100;
});

4.
const randomNumbers = [375, 200, 3.14, 7, 13, 852];

// Call .filter() on randomNumbers below
const smallNumbers=randomNumbers.filter(number=>{
  return number<250;
});


const favoriteWords = ['nostalgia', 'hyperbole', 'fervent', 'esoteric', 'serene'];


// Call .filter() on favoriteWords below

const longFavoriteWords=favoriteWords.filter(words=>{
  return words.length>7;
});

5.
const animals = ['hippo', 'tiger', 'lion', 'seal', 'cheetah', 'monkey', 'salamander', 'elephant'];

const foundAnimal=animals.findIndex(animal=>{
  return animal==='elephant';
});
const startsWithS=animals.findIndex(animal=>{
  return animal[0]==='s' ? true : false;
});

6.
const newNumbers = [1, 3, 5, 7];

const newSum=newNumbers.reduce((accumulator,currentValue)=>{
console.log('The value of accumulator: ',accumulator);
console.log('The value of currentvalue: ',currentValue);
return accumulator+currentValue;
},10);
console.log(newSum);

7.
const words = ['unique', 'uncanny', 'pique', 'oxymoron', 'guise'];

// Something is missing in the method call below

console.log(words.some(word=> {
  return word.length < 6;
}));

// Use filter to create a new array

const interestingWords=words.filter(word=>{
  return word.length>5;
});

// Make sure to uncomment the code below and fix the incorrect code before running it

console.log(interestingWords.every((word) => { return word.length>5} ));

8.
const cities = ['Orlando', 'Dubai', 'Edinburgh', 'Chennai', 'Accra', 'Denver', 'Eskisehir', 'Medellin', 'Yokohama'];

const nums = [1, 50, 75, 200, 350, 525, 1000];

//  Choose a method that will return undefined
cities.forEach(city => console.log('Have you visited ' + city + '?'));

// Choose a method that will return a new array
const longCities = cities.filter(city => city.length > 7);

// Choose a method that will return a single value
const word = cities.reduce((acc, currVal) => {
  return acc + currVal[0]
}, "C");

console.log(word)

// Choose a method that will return a new array
const smallerNums = nums.map(num => num - 5);

// Choose a method that will return a boolean value
nums.every(num => num < 0);

************************Objects
1.
// Write your fasterShip object literal below
let fasterShip={
  color:'silver',
  'Fuel Type':'Turbo Fuel'
};

2.
let spaceship = {
  homePlanet: 'Earth',
  color: 'silver',
  'Fuel Type': 'Turbo Fuel',
  numCrew: 5,
  flightPath: ['Venus', 'Mars', 'Saturn']
};

// Write your code below
let crewCount=spaceship.numCrew;
let planetArray=spaceship.flightPath;

3.
let spaceship = {
  'Fuel Type' : 'Turbo Fuel',
  'Active Mission' : true,
  homePlanet : 'Earth', 
  numCrew: 5
 };

let propName =  'Active Mission';

// Write your code below
let isActive=spaceship['Active Mission'];
console.log(spaceship[propName]);

4.
let spaceship = {
  'Fuel Type' : 'Turbo Fuel',
  homePlanet : 'Earth',
  color: 'silver',
  'Secret Mission' : 'Discover life outside of Earth.'
};

// Write your code below
spaceship.color='glorious gold';
spaceship.numEngines=1;
delete spaceship['Secret Mission'];

5.
let retreatMessage = 'We no longer wish to conquer your planet. It is full of dogs, which we do not care for.';

// Write your code below
const alienShip={
retreat(){
  console.log(retreatMessage);
},
takeOff(){
  console.log('Spim... Borp... Glix... Blastoff!');
}
};

alienShip.retreat();
alienShip.takeOff();

6.
let spaceship = {
  passengers: [{one:"sanket"}],
  telescope: {
    yearBuilt: 2018,
    model: "91031-XLT",
    focalLength: 2032 
  },
  crew: {
    captain: { 
      name: 'Sandra', 
      degree: 'Computer Engineering', 
      encourageTeam() { console.log('We got this!') },
     'favorite foods': ['cookies', 'cakes', 'candy', 'spinach'] }
  },
  engine: {
    model: "Nimbus2000"
  },
  nanoelectronics: {
    computer: {
      terabytes: 100,
      monitors: "HD"
    },
    'back-up': {
      battery: "Lithium",
      terabytes: 50
    }
  }
}; 
let capFave=spaceship.crew.captain['favorite foods'][0];
let firstPassenger=spaceship.passengers[0];

7.
let spaceship = {
  'Fuel Type' : 'Turbo Fuel',
  homePlanet : 'Earth'
};

// Write your code below
const greenEnergy= obj=>{
  obj['Fuel Type']='avocado oil';
  };
   
  const remotelyDisable= obj =>{
    obj.disabled = true;
  };

  greenEnergy(spaceship);
  remotelyDisable(spaceship);

  console.log(spaceship);

8.
let spaceship = {
  crew: {
  captain: { 
      name: 'Lily', 
      degree: 'Computer Engineering', 
      cheerTeam() { console.log('You got this!') } 
      },
  'chief officer': { 
      name: 'Dan', 
      degree: 'Aerospace Engineering', 
      agree() { console.log('I agree, captain!') } 
      },
  medic: { 
      name: 'Clementine', 
      degree: 'Physics', 
      announce() { console.log(`Jets on!`) } },
  translator: {
      name: 'Shauna', 
      degree: 'Conservation Science', 
      powerFuel() { console.log('The tank is full!') } 
      }
  }
}; 

// Write your code below
for(let crewMember in spaceship.crew){
  console.log(`${crewMember}: ${spaceship.crew[crewMember].name}`);
}
for(let crewmem in spaceship.crew){
console.log(`${spaceship.crew[crewmem].name}: ${spaceship.crew[crewmem].degree}`);
}

********************advanced objects
1.
const robot = {
  model:'1E78V2',
  energyLevel:100,
  provideInfo(){
    return `I am ${this.model} and my current energy level is ${this.energyLevel}.`;
  }
};
console.log(robot.provideInfo());

2.
const robot = {
  energyLevel: 100,
  checkEnergy: function() {
    console.log(`Energy is currently at ${this.energyLevel}%.`)
  }
}

robot.checkEnergy();

3
const robot = {
  _energyLevel: 'high',
  recharge(){
    this._energyLevel += 30;
    console.log(`Recharged! Energy is currently at ${this._energyLevel}%.`)
  }
};

robot.recharge();

4.
const robot = {
  _model: '1E78V2',
  _energyLevel: 100,
  get energyLevel(){
    if(typeof this._energyLevel === 'number'){
      return 'My current energy level is ' +this._energyLevel;
    }
    else{
      return 'System malfunction: cannot retrieve energy level';
    }
  }
};
console.log(robot.energyLevel);


5.
const robot = {
  _model: '1E78V2',
  _energyLevel: 100,
  _numOfSensors: 15,
  get numOfSensors(){
    if(typeof this._numOfSensors === 'number'){
      return this._numOfSensors;
    } else {
      return 'Sensors are currently down.'
    }
  },
  set numOfSensors(num){
    if(typeof num==='number'&& num>=0){
     this._numOfSensors=num;
    }
    else{
     console.log('Pass in a number that is greater than or equal to 0');
    }

  }
  
};

robot.numOfSensors = 100;
console.log(robot.numOfSensors);

6.
const robotFactory=(model,mobile)=>{
  return {
    model:model,
    mobile:mobile,
    beep(){
      console.log("Beep Boop");
    }
  };
}
const tinCan=robotFactory('P-500',true);
tinCan.beep();

7.
const robotFactory = (model, mobile) => {
  return {
    model,
    mobile,
    beep() {
      console.log('Beep Boop');
    }
  }
}

// To check that the property value shorthand technique worked:
const newRobot = robotFactory('P-501', false)
console.log(newRobot.model)
console.log(newRobot.mobile)

8.
const robot = {
  model: '1E78V2',
  energyLevel: 100,
  functionality: {
    beep() {
      console.log('Beep Boop');
    },
    fireLaser() {
      console.log('Pew Pew');
    },
  }
};
const {functionality}=robot;
functionality.beep();

9.
const robot = {
	model: 'SAL-1000',
  mobile: true,
  sentient: false,
  armor: 'Steel-plated',
  energyLevel: 75
};

// What is missing in the following method call?
const robotKeys = Object.keys(robot);

console.log(robotKeys);

// Declare robotEntries below this line:
const robotEntries=Object.entries(robot);

console.log(robotEntries);

// Declare newRobot below this line:

const newRobot=Object.assign({laserBlaster:true,voiceRecognition:true},robot);
console.log(newRobot);

10.
