
const result=(callback)=>{
    const arr=[1,2,3,4];
  setTimeout(()=>{
    callback(arr);
  },3000);
}
const outcome=result(x=>{
    for(let i of x){
        console.log(i);
    }
});
// Create an Array
// const myNumbers = [4, 1, -20, -7, 5, 9, -6];

// // Call removeNeg with a callback
// const posNumbers = removeNeg(myNumbers, (x) => x >= 0);

// // Display Result

// // Keep only positive numbers
// function removeNeg(numbers, callback) {
//   const myArray = [];
//   for (const x of numbers) {
//     if (callback(x)) {
//       myArray.push(x);
//     }
//   }
//   return myArray;
// }

// console.log(posNumbers);